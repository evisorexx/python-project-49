### Hexlet tests and linter status:
[![Actions Status](https://github.com/evisorexx/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/evisorexx/python-project-49/actions)
### CodeClimate Maintainability:
[![Maintainability](https://api.codeclimate.com/v1/badges/aea1d14b808122797bce/maintainability)](https://codeclimate.com/github/evisorexx/python-project-49/maintainability)
### Brain Even test video:
[![asciicast](https://asciinema.org/a/rZJbr239ztghdsCevA6tL3FpM.svg)](https://asciinema.org/a/rZJbr239ztghdsCevA6tL3FpM)
